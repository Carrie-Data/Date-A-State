// API key
const API_KEY = "pk.eyJ1IjoiY2FycmllY29vazgyIiwiYSI6ImNqeDEzczdtZDAwdXY0OW16a2l3Y2l4ajgifQ.jed0UPy56AfZMI1sa3vO5A";
